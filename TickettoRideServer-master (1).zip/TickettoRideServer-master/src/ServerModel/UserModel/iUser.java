package ServerModel.UserModel;

/**
 * Created by benjamin on 6/02/17.
 */
public interface iUser {
}
