package ServerModel.Models;

/**
 * Created by raulbr on 2/13/17.
 */
public class GameModel {
    public String _gameName;
    public int _numberOfPlayers;
    public boolean _active;
}
