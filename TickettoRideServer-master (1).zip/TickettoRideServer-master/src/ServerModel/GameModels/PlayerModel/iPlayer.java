package ServerModel.GameModels.PlayerModel;
import ServerModel.UserModel.iUser;

/**
 * Created by benjamin on 6/02/17.
 */
public interface iPlayer extends iUser {
}
